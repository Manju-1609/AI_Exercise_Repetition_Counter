import cv2
import face_recognition
from PIL import Image, ImageDraw

cap = cv2.VideoCapture(0)
op = 0

img1 = face_recognition.load_image_file('images/Monica.jpg')
img1_encoding = face_recognition.face_encodings(img1)[0]

img2 = face_recognition.load_image_file('images/rachel.jpg')
img2_encoding = face_recognition.face_encodings(img2)[0]


#  Create arrays of encodings and names
known_face_encodings = [
    img1_encoding,
    img2_encoding,
    #img3_encoding
]

known_face_names = [
    "Monica",
    "Rachel",
    #"Seokjin"
]
#currently hard-coded values, to be changed

while True:
    result, frame = cap.read()

    face_locations = face_recognition.face_locations(frame)
    face_encodings = face_recognition.face_encodings(frame, face_locations)

    pil_image = Image.fromarray(frame)
    draw = ImageDraw.Draw(pil_image)

    for (top, right, bottom, left), face_encoding in zip(face_locations, face_encodings):
        matches = face_recognition.compare_faces(known_face_encodings, face_encoding)

        name = "Unknown"

        if True in matches:
            first_match_index = matches.index(True)
            name = known_face_names[first_match_index]
            op = 1
            print("Authentication success!")
        else:
            op = 0
            print("Authentication failed: User profile and current image doesn't match")

        # Draw box
        draw.rectangle(((left, top), (right, bottom)), outline=(255, 255, 0))
        # print(left, top, right, bottom)

        # Draw label
        text_width, text_height = draw.textsize(name)
        draw.rectangle(((left, top - 10), (right, top)), fill=(255, 255, 0), outline=(255, 255, 0))
        draw.text((left, top - 10), name, fill=(0, 0, 0))
    del draw

    cv2.imshow("image", frame)

    if (op==1 ): #or (op==0 & cv2.waitKey(10000)):
    #if cv2.waitKey(1) & 0xFF == ord('q'):
        cv2.waitKey(2000)
        #im = Image.open("./auth_success.png")
        #im.imshow()
        break
    elif(0xFF == ord('q')):
        print("Auth failed! quit by user")
        break
    else:
        #diaply auth failed img
        print("Auth failed")

cap.release()
cv2.destroyAllWindows()