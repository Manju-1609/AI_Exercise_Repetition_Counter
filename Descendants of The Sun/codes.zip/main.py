
print("\n 1. Curls \n 2. Lunges")
exer = int(input("\n Enter the type of exercise: "))


if exer == 1:
    import final
    exec('final')
else:
    import lunges
    exec('lunges')
